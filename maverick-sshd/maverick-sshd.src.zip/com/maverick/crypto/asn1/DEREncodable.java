package com.maverick.crypto.asn1;

public abstract interface DEREncodable
{
  public abstract DERObject getDERObject();
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.crypto.asn1.DEREncodable
 * JD-Core Version:    0.6.0
 */