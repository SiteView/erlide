package com.maverick.crypto.asn1;

public class ASN1EncodableVector extends DEREncodableVector
{
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.crypto.asn1.ASN1EncodableVector
 * JD-Core Version:    0.6.0
 */