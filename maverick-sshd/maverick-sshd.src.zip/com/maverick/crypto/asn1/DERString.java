package com.maverick.crypto.asn1;

public abstract interface DERString
{
  public abstract String getString();
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.crypto.asn1.DERString
 * JD-Core Version:    0.6.0
 */