package com.maverick.crypto.publickey;

public abstract interface PublicKey
{
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.crypto.publickey.PublicKey
 * JD-Core Version:    0.6.0
 */