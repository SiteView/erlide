package com.maverick.sshd;

public abstract interface TransportProtocolListener
{
  public abstract void onDisconnect(TransportProtocol paramTransportProtocol);
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.sshd.TransportProtocolListener
 * JD-Core Version:    0.6.0
 */