package com.maverick.sshd.platform;

public class PasswordChangeException extends Exception
{
  public PasswordChangeException()
  {
  }

  public PasswordChangeException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.sshd.platform.PasswordChangeException
 * JD-Core Version:    0.6.0
 */