package com.maverick.sshd.platform;

public class UnsupportedFileOperationException extends Exception
{
  public UnsupportedFileOperationException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.sshd.platform.UnsupportedFileOperationException
 * JD-Core Version:    0.6.0
 */