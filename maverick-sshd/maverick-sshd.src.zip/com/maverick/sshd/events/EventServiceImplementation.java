package com.maverick.sshd.events;

public class EventServiceImplementation extends com.maverick.events.EventServiceImplementation
{
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.sshd.events.EventServiceImplementation
 * JD-Core Version:    0.6.0
 */