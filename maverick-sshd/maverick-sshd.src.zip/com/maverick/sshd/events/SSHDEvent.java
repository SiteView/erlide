package com.maverick.sshd.events;

import com.maverick.events.Event;

public class SSHDEvent extends Event
{
  public SSHDEvent(Object paramObject, int paramInt, boolean paramBoolean)
  {
    super(paramObject, paramInt, paramBoolean);
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.sshd.events.SSHDEvent
 * JD-Core Version:    0.6.0
 */