package com.maverick.sshd.events;

public final class EventLog extends com.maverick.nio.EventLog
{
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.sshd.events.EventLog
 * JD-Core Version:    0.6.0
 */