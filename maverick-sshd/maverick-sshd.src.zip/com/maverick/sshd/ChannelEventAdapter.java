package com.maverick.sshd;

public class ChannelEventAdapter
  implements ChannelEventListener
{
  public void onChannelOpen(Channel paramChannel)
  {
  }

  public void onChannelClose(Channel paramChannel)
  {
  }

  public void onChannelEOF(Channel paramChannel)
  {
  }

  public void onChannelClosing(Channel paramChannel)
  {
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.sshd.ChannelEventAdapter
 * JD-Core Version:    0.6.0
 */