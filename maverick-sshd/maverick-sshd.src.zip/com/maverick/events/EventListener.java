package com.maverick.events;

public abstract interface EventListener
{
  public abstract void processEvent(Event paramEvent);
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.events.EventListener
 * JD-Core Version:    0.6.0
 */