package com.maverick.nio;

public abstract interface SocketWriteCallback
{
  public abstract void completedWrite();
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.nio.SocketWriteCallback
 * JD-Core Version:    0.6.0
 */