package com.maverick.nio;

public class Event extends com.maverick.events.Event
{
  public Event(Object paramObject, int paramInt, boolean paramBoolean)
  {
    super(paramObject, paramInt, paramBoolean);
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.nio.Event
 * JD-Core Version:    0.6.0
 */