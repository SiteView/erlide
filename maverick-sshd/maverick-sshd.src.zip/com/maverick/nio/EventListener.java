package com.maverick.nio;

public abstract interface EventListener extends com.maverick.events.EventListener
{
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.nio.EventListener
 * JD-Core Version:    0.6.0
 */