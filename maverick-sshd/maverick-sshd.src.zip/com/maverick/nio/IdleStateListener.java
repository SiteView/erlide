package com.maverick.nio;

public abstract interface IdleStateListener
{
  public abstract boolean idle();
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.nio.IdleStateListener
 * JD-Core Version:    0.6.0
 */