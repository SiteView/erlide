package com.maverick.nio;

import java.io.IOException;

public class LicenseException extends IOException
{
  public LicenseException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.nio.LicenseException
 * JD-Core Version:    0.6.0
 */