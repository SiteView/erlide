package com.maverick.nio;

public class LicenseManager
{
  public static void addLicense(String paramString)
  {
    Daemon.G.A(paramString);
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.nio.LicenseManager
 * JD-Core Version:    0.6.0
 */