package com.maverick.ssh.components;

public abstract interface SshKeyExchange
{
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.SshKeyExchange
 * JD-Core Version:    0.6.0
 */