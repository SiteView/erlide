package com.maverick.ssh.components.jce;

public abstract interface AbstractPublicKey
{
  public abstract String getProvider();
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.jce.AbstractPublicKey
 * JD-Core Version:    0.6.0
 */