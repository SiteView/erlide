package com.maverick.ssh.components.jce;

public abstract interface AbstractKeyExchange
{
  public abstract String getProvider();
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.jce.AbstractKeyExchange
 * JD-Core Version:    0.6.0
 */