package com.maverick.ssh.components.standalone;

public class Twofish128Cbc extends A
{
  public static final String TWOFISH128_CBC = "twofish128-cbc";

  public Twofish128Cbc()
  {
    super(128, new C(), "twofish128-cbc");
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.standalone.Twofish128Cbc
 * JD-Core Version:    0.6.0
 */