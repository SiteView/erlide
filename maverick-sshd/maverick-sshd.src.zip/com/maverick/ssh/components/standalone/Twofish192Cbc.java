package com.maverick.ssh.components.standalone;

public class Twofish192Cbc extends A
{
  public static final String TWOFISH192_CBC = "twofish192-cbc";

  public Twofish192Cbc()
  {
    super(192, new C(), "twofish192-cbc");
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.standalone.Twofish192Cbc
 * JD-Core Version:    0.6.0
 */