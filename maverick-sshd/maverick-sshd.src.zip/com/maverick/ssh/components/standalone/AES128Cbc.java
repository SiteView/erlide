package com.maverick.ssh.components.standalone;

public class AES128Cbc extends A
{
  public static final String AES128_CBC = "aes128-cbc";

  public AES128Cbc()
  {
    super(128, new B(), "aes128-cbc");
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.standalone.AES128Cbc
 * JD-Core Version:    0.6.0
 */