package com.maverick.ssh.components.standalone;

public class AES256Ctr extends D
{
  public static final String AES256_CTR = "aes256-ctr";

  public AES256Ctr()
  {
    super(256, new B(), "aes256-ctr");
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.standalone.AES256Ctr
 * JD-Core Version:    0.6.0
 */