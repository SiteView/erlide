package com.maverick.ssh.components.standalone;

public class AES192Cbc extends A
{
  public static final String AES192_CBC = "aes192-cbc";

  public AES192Cbc()
  {
    super(192, new B(), "aes192-cbc");
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.standalone.AES192Cbc
 * JD-Core Version:    0.6.0
 */