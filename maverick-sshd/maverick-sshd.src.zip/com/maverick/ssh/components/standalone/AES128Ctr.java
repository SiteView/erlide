package com.maverick.ssh.components.standalone;

public class AES128Ctr extends D
{
  public static final String AES128_CTR = "aes128-ctr";

  public AES128Ctr()
  {
    super(128, new B(), "aes128-ctr");
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.standalone.AES128Ctr
 * JD-Core Version:    0.6.0
 */