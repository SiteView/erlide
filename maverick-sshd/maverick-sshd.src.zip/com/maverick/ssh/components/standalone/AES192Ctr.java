package com.maverick.ssh.components.standalone;

public class AES192Ctr extends D
{
  public static final String AES192_CTR = "aes192-ctr";

  public AES192Ctr()
  {
    super(192, new B(), "aes192-ctr");
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.components.standalone.AES192Ctr
 * JD-Core Version:    0.6.0
 */