package com.maverick.ssh;

public class ShellTimeoutException extends Exception
{
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.ssh.ShellTimeoutException
 * JD-Core Version:    0.6.0
 */