package com.maverick.util;

import java.io.ByteArrayOutputStream;

public class SimpleASNWriter
{
  private ByteArrayOutputStream A = new ByteArrayOutputStream();

  public void writeByte(int paramInt)
  {
    this.A.write(paramInt);
  }

  public void writeData(byte[] paramArrayOfByte)
  {
    writeLength(paramArrayOfByte.length);
    this.A.write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public void writeLength(int paramInt)
  {
    if (paramInt < 128)
    {
      this.A.write(paramInt);
    }
    else if (paramInt < 256)
    {
      this.A.write(129);
      this.A.write(paramInt);
    }
    else if (paramInt < 65536)
    {
      this.A.write(130);
      this.A.write(paramInt >>> 8);
      this.A.write(paramInt);
    }
    else if (paramInt < 16777216)
    {
      this.A.write(131);
      this.A.write(paramInt >>> 16);
      this.A.write(paramInt >>> 8);
      this.A.write(paramInt);
    }
    else
    {
      this.A.write(132);
      this.A.write(paramInt >>> 24);
      this.A.write(paramInt >>> 16);
      this.A.write(paramInt >>> 8);
      this.A.write(paramInt);
    }
  }

  public byte[] toByteArray()
  {
    return this.A.toByteArray();
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.util.SimpleASNWriter
 * JD-Core Version:    0.6.0
 */