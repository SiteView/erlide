package com.maverick.util;

import java.io.IOException;

public class SimpleASNReader
{
  private byte[] A;
  private int B;

  public SimpleASNReader(byte[] paramArrayOfByte)
  {
    this.A = paramArrayOfByte;
    this.B = 0;
  }

  public void assertByte(int paramInt)
    throws IOException
  {
    int i = getByte();
    if (i != paramInt)
      throw new IOException("Assertion failed, next byte value is " + Integer.toHexString(i) + " instead of asserted " + Integer.toHexString(paramInt));
  }

  public int getByte()
  {
    return this.A[(this.B++)] & 0xFF;
  }

  public byte[] getData()
  {
    int i = getLength();
    return A(i);
  }

  public int getLength()
  {
    int i = this.A[(this.B++)] & 0xFF;
    if ((i & 0x80) != 0)
    {
      int j = 0;
      for (int k = i & 0x7F; k > 0; k--)
      {
        j <<= 8;
        j |= this.A[(this.B++)] & 0xFF;
      }
      return j;
    }
    return i;
  }

  private byte[] A(int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(this.A, this.B, arrayOfByte, 0, paramInt);
    this.B += paramInt;
    return arrayOfByte;
  }

  public boolean hasMoreData()
  {
    return this.B < this.A.length;
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.maverick.util.SimpleASNReader
 * JD-Core Version:    0.6.0
 */