package com.sshtools.zlib;

public class OpenSSHZLibCompression extends ZLibCompression
{
  public String getAlgorithm()
  {
    return "zlib@openssh.com";
  }
}

/* Location:           C:\src\maverick-sshd\dist\maverick-sshd.jar
 * Qualified Name:     com.sshtools.zlib.OpenSSHZLibCompression
 * JD-Core Version:    0.6.0
 */